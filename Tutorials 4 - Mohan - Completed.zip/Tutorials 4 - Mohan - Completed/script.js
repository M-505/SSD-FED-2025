const numbers = [5, 10, 15, 20];


const tripled = numbers.map(num => num * 3);
const filtered = tripled.filter(num => num > 10);
const sum = filtered.reduce((accumulator, current) => accumulator + current, 0);

console.log("Original:", numbers);
console.log("Tripled:", tripled);
console.log("Filtered (>10):", filtered);
console.log("Sum:", sum);

